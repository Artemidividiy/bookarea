cd bookarea
rails spec