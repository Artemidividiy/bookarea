RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
echo -e ' ${BLUE} starting application${NC}'
cd bookarea && rails s