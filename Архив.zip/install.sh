echo 'instalation started'

cd bookarea
bundle install & yarn install

echo 'installation complete'

bash launch.sh